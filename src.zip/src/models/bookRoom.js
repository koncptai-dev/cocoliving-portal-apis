const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const User = require('./user');
const PropertyRateCard = require('./propertyRateCard');
const Room = require('./rooms');

const Booking = sequelize.define(
  'Booking',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    propertyId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: User, key: 'id' },
    },

    rateCardId: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: { model: PropertyRateCard, key: 'id' }, 
    },

    bookingSource: {
      type: DataTypes.ENUM('ONLINE', 'OFFLINE'),
      allowNull: false,
      defaultValue: 'ONLINE'
    },

    roomType: {
      type: DataTypes.STRING,
      allowNull: false,
    },

    roomId: {
      type: DataTypes.INTEGER,
      allowNull: true,
      references: { model: Room, key: 'id' },
    },
    assignedItems: {
      type: DataTypes.JSON,
      allowNull: true,
      defaultValue: [],
    },

    checkInDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },

    checkOutDate: {
      type: DataTypes.DATEONLY,
      allowNull: false,
    },

    duration: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },

    monthlyRent: {
      type: DataTypes.FLOAT,
      allowNull: false,
    },

    status: {
      type: DataTypes.STRING,
      allowNull: false,
      defaultValue: 'pending',
    },

    totalAmount: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Total amount in Rupees (monthlyRent * duration + security deposit i.e. monthRent*2)',
    },

    remainingAmount: {
      type: DataTypes.INTEGER,
      allowNull: true,
      comment: 'Remaining amount in Rupees',
    },

    bookingType: {
      type: DataTypes.ENUM('PREBOOK', 'BOOK'),
      allowNull: false,
      defaultValue:'BOOK',
    },

    paymentStatus: {
      type: DataTypes.ENUM('INITIATED', 'PARTIAL', 'COMPLETED'),
      allowNull: false,
      defaultValue: 'INITIATED',
    },
    onboardingStatus: {
      type: DataTypes.ENUM('NOT_INITIATED', 'INITIATED', 'OTP_PENDING', 'COMPLETED'),
      allowNull: false,
      defaultValue: 'NOT_INITIATED'
    },
    contractStatus: {
      type: DataTypes.ENUM("NOT_SIGNED", "SIGNED"),
      allowNull: false,
      defaultValue: "NOT_SIGNED",
    },
    adminContractStatus: {
      type: DataTypes.ENUM("NOT_SIGNED", "SIGNED"),
      allowNull: false,
      defaultValue: "NOT_SIGNED",
    },
    cancelRequestStatus: {
      type: DataTypes.ENUM('NONE','PENDING','APPROVED','REJECTED'),
      allowNull: false,
      defaultValue:'NONE',
    },
    userCancelReason: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    adminCancelReason: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    cancelEffectiveCheckOutDate: {
      type: DataTypes.DATEONLY,
      allowNull: true,
    },
    securityDepositPaid: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    monthlyPlanSelected: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    monthlyInstallment: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    installmentsPaid: {
      type: DataTypes.INTEGER,
      defaultValue: 0
    },
    firstElectricityRechargeDone: {
      type: DataTypes.BOOLEAN,
      defaultValue: false
    },
    alisteUserId: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    removedUserFromAliste: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
    },
    meta: {
      type: DataTypes.JSON,
      allowNull: true,
    },
  },

  {
    tableName: 'bookings',
  }
);

module.exports = Booking;
