const { DataTypes } = require("sequelize");
const sequelize = require("../config/database");

const DraftPaymentTransaction = sequelize.define(
  "DraftPaymentTransaction",
  {
    id: {
      type: DataTypes.BIGINT,
      primaryKey: true,
      autoIncrement: true,
    },
    draftBookingId: {
      type: DataTypes.BIGINT,
      allowNull: false,
    },
    userId: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    merchantOrderId: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    amount: {
      type: DataTypes.BIGINT,
      allowNull: false,
      comment: "Amount in paise (integer)",
    },
    type: {
      type: DataTypes.ENUM("OFFLINE"),
      allowNull: false,
      defaultValue: "OFFLINE",
    },
    status: {
      type: DataTypes.ENUM("PENDING", "SUCCESS", "FAILED", "EXPIRED"),
      allowNull: false,
      defaultValue: "PENDING",
    },
    paymentMode: {
      type: DataTypes.ENUM("ONLINE", "OFFLINE"),
      allowNull: false,
      defaultValue: "OFFLINE",
    },
    paymentDate: {
      type: DataTypes.STRING(10),
      allowNull: true,
    },
    offlinePaymentType: {
      type: DataTypes.ENUM("CASH", "CHEQUE", "UPI"),
      allowNull: true,
    },
    adminNote: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    paymentImage: {
      type: DataTypes.TEXT,
      allowNull: true,
    },
    acknowledgementPdfPath: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    createdByAdminId: {
      type: DataTypes.INTEGER,
      allowNull: true,
    },
    rawResponse: {
      type: DataTypes.JSON,
      allowNull: true,
    },
    meta: {
      type: DataTypes.JSON,
      allowNull: true,
    },
  },
  {
    tableName: "draft_payment_transactions",
    timestamps: true,
  }
);

module.exports = DraftPaymentTransaction;
