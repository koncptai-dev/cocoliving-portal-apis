const express = require("express");
const DraftBooking = require("../controllers/DraftBooking");
const authMiddleware = require("../middleware/auth");
const authorizeRole = require("../middleware/authorizeRole");
const authorizePage = require("../middleware/authorizePage");

const router = express.Router();

router.get( "/payment-form", authMiddleware, authorizeRole(1, 3), authorizePage("Bookings", "read"), DraftBooking.getBookingPaymentFormData );
router.post( "/payment-form/review", authMiddleware, authorizeRole(1, 3), authorizePage("Bookings", "write"), DraftBooking.reviewBookingPayment );
router.post( "/payment-form/confirm", authMiddleware, authorizeRole(1, 3), authorizePage("Bookings", "write"), DraftBooking.confirmBookingPayment );
router.post( "/", DraftBooking.draftBooking );

module.exports = router;
