const express = require("express");
const router = express.Router();
const controller = require("../controllers/inventoryController");
const csvController = require("../controllers/inventoryCsvController.js");
const authenticateToken = require("../middleware/auth");
const uploadCSV = require("../middleware/uploadCsv.js");
const authorizeRole = require("../middleware/authorizeRole");
const authorizePage = require("../middleware/authorizePage");

//CSV Routes admin
router.get("/export/csv", authenticateToken,authorizeRole(1,3), csvController.exportInventory);// Export modes : export all inventory items & export inventory items of a specific property ( use ?propertyId= at end of request to filter by property )

// admin
router.post("/import/csv", authenticateToken, authorizeRole(1,3), uploadCSV.single("file"), csvController.importInventory);
router.get("/template", authenticateToken, authorizeRole(1,3), csvController.downloadTemplate);

//Normal Routes
router.post("/", authenticateToken, authorizeRole(1,3),authorizePage("Inventory Management","write"), controller.addInventory);
router.get("/", authenticateToken, authorizeRole(1,3), authorizePage("Inventory Management","read"), controller.getAllInventory);
router.get("/:id", authenticateToken, authorizePage("Inventory Management","read"), controller.getInventoryById);
router.post("/by-ids",authenticateToken, authorizePage("Inventory Management","read"), controller.getInventoryByIds);
router.get("/qr/inventory/:inventoryId", authenticateToken, authorizeRole(1,3), authorizePage("Inventory Management","read"), controller.generateInventoryQr );
router.get("/qr/room/:roomId", authenticateToken, authorizeRole(1,3), authorizePage("Inventory Management","read"), controller.generateRoomQrPdf);
router.get("/qr/property/:propertyId", authenticateToken, authorizeRole(1,3), authorizePage("Inventory Management","read"), controller.generatePropertyQrPdf);
router.put("/:id", authenticateToken, authorizePage("Inventory Management","write"), controller.updateInventory);
router.delete("/:id", authenticateToken, authorizePage("Inventory Management","write"), controller.deleteInventory);
router.get('/available/:roomId',authenticateToken, controller.getAvailableByRoom);

module.exports = router;