const sequelize = require('../config/database');
const User = require('../models/user');
const UserPermission = require('../models/userPermissoin');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { mailsender } = require('../utils/emailService');
const { Op } = require('sequelize');
const { welcomeEmail, adminCredentialsEmail } = require('../utils/emailTemplates/emailTemplates');
const { logApiCall } = require("../helpers/auditLog");

exports.AddUser = async (req, res) => {
    try {
        const { email, fullName, phone, userType, } = req.body;

        if (!email || !fullName || !phone) {
            await logApiCall(req, res, 400, "Added user - required fields missing", "user");
            return res.status(400).json({ message: "Required fields are missing" });
        }

        const existingUser = await User.findOne({
            where: {
                [Op.or]: [
                    { email },
                    { phone }
                ]
            }
        });

        if (existingUser) {
            if (existingUser.email === email) {
                return res.status(400).json({
                    message: "Email already exists"
                });
            }

            if (existingUser.phone === phone) {
                return res.status(400).json({
                    message: "Mobile number already exists"
                });
            }
        }

        const newUser = await User.create({
            email,
            fullName,
            phone,
            userType,
            status: 1,
        });
        try {
            const mail = welcomeEmail({ firstName: newUser.fullName });
            await mailsender(
                newUser.email,
                'Welcome to Coco Living',
                mail.html,
                mail.attachments
            );
        } catch (err) {
            console.error('Welcome email failed:', err.message);
        }
        await logApiCall(req, res, 201, `Added new user: ${fullName} (${email}, ID: ${newUser.id})`, "user", newUser.id);
        res.status(201).json({
            message: `User added successfully.Login email sent to ${email}`,
            user: newUser
        });

    } catch (error) {
        console.error(error);
        await logApiCall(req, res, 500, "Error occurred while adding user", "user");
        res.status(500).json({ message: "Server error", error: error.message });
    }
}

exports.getAllUser = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search || "";
        const offset = (page - 1) * limit;

        const where = {
            userType: { [Op.notIn]: ["super-admin", "admin"] }
        };

        if (search) {
            where[Op.or] = [
                { fullName: { [Op.iLike]: `%${search}%` } },
                { email: { [Op.iLike]: `%${search}%` } },
                { phone: { [Op.iLike]: `%${search}%` } }
            ];
        }

        const { rows: users, count } = await User.findAndCountAll({
            where,
            order: [['createdAt', 'DESC']],
            limit,
            offset
        });

        await logApiCall(req, res, 200, "Viewed all users list", "user");

        res.json({
            users,
            currentPage: page,
            totalPages: Math.ceil(count / limit),
            totalUsers: count
        });

    } catch (error) {
        await logApiCall(req, res, 500, "Error occurred while fetching all users", "user");
        res.status(500).json({ message: "Failed to fetch Users" });
    }
}

exports.getNormalUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      where: { role: 2 }, // only normal users
      attributes: ["id", "fullName", "email"],
      order: [["fullName", "ASC"]],
    });

    res.json({ users });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch users" });
  }
};


//create admin user
exports.createAdminUser = async (req, res) => {
    const t = await sequelize.transaction(); //  Start transaction
    try {
        const { email, fullName, phone, password, roleName, pages, permissions, properties } = req.body;

        // Check existing email
        const existing = await User.findOne({ where: { email }, transaction: t });
        if (existing) {
            await t.rollback();
            await logApiCall(req, res, 400, `Created admin user - email already exists (${email})`, "user");
            return res.status(400).json({ message: "Email already exists" });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);

        // Create user
        const newAdminUser = await User.create({
            email,
            fullName,
            phone,
            password: hashedPassword,
            role: 3,
            status: 1,
            roleName,
            userType: "admin",
        }, { transaction: t });

        // Create permission
        const userPermission = await UserPermission.create({
            userId: newAdminUser.id,
            pages,
            permissions,
            properties
        }, { transaction: t });

        // Commit if all OK
        await t.commit();

        //send email with credentials
        const emailTemplate = adminCredentialsEmail({ fullName, email, password });

        await mailsender(email, "Admin Account Created", emailTemplate.html, emailTemplate.attachments);

        await logApiCall(req, res, 201, `Created admin user & email sent (${email})`, "user", newAdminUser.id);
        res.status(201).json({
            message: "Admin created successfully  & email sent",
            admin: newAdminUser,
            permission: userPermission
        });

    } catch (error) {
        console.error(error);
        // Rollback on any error
        await t.rollback();
        await logApiCall(req, res, 500, "Error occurred while creating admin user", "user");
        res.status(500).json({ message: "Error creating admin", error: error.message });
    }
};

exports.editAdminUser = async (req, res) => {
    const t = await sequelize.transaction();
    try {
        const { id } = req.params;
        const { email, fullName, phone, roleName, pages, permissions, properties } = req.body;

        //Check if user exists
        const adminUser = await User.findOne({
            where: { id, [Op.or]: [{ userType: "admin" }, { role: 3 }] },
            transaction: t
        });

        if (!adminUser) {
            await t.rollback();
            return res.status(404).json({ message: "Admin not found" });
        }

        // Prepare update data
        const updatedData = {
            email,
            fullName,
            phone,
            roleName
        };

        //  Update user
        await adminUser.update(updatedData, { transaction: t });

        // Update or create permission
        const existingPermission = await UserPermission.findOne({
            where: { userId: adminUser.id },
            transaction: t
        });

        if (existingPermission) {
            await existingPermission.update({
                pages,
                permissions,
                properties
            }, { transaction: t });
        } else {
            await UserPermission.create({
                userId: adminUser.id,
                pages,
                permissions,
                properties
            }, { transaction: t });
        }

        // Commit everything
        await t.commit();

        await logApiCall(req, res, 200, `Updated admin user: ${adminUser.fullName} (ID: ${id})`, "user", parseInt(id));
        res.status(200).json({
            message: "Admin updated successfully",
            admin: adminUser
        });

    } catch (error) {
        console.error("Error updating admin:", error);
        await t.rollback();
        await logApiCall(req, res, 500, "Error occurred while updating admin user", "user", parseInt(req.params.id) || 0);
        res.status(500).json({ message: "Error updating admin", error: error.message });
    }
};

exports.getAllAdminUsers = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const search = req.query.search || "";

        const offset = (page - 1) * limit;

        const where = {
            [Op.or]: [
                { userType: "admin" },
                { role: 3 }
            ]
        };

        if (search) {
            where[Op.and] = [{[Op.or]: [
                { fullName: { [Op.iLike]: `%${search}%` } },
                { email: { [Op.iLike]: `%${search}%` } },
                { phone: { [Op.iLike]: `%${search}%` } },
                { roleName: { [Op.iLike]: `%${search}%` } }
            ]}];
        }
        const { rows: adminUsers, count } = await User.findAndCountAll({
            where,
            include: {
                model: UserPermission,
                as: 'permission'
            },
            order: [["createdAt", "DESC"]],
            limit,
            offset
        });
        await logApiCall(req, res, 200, "Viewed all admin users list", "user");
        res.json({
            adminUsers,
            currentPage: page,
            totalPages: Math.ceil(count / limit),
            totalAdmins: count
        });
    } catch (error) {
        console.error(error);
        await logApiCall(req, res, 500, "Error occurred while fetching all admin users", "user");
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

exports.getAdminById = async (req, res) => {
    try {
        const { id } = req.params;

        // Fetch admin by primary key
        const admin = await User.findOne({
            where: {
                id,
                [Op.or]: [
                    { userType: "admin" },
                    { role: 3 }
                ]
            },
            include: {
                model: UserPermission,
                as: 'permission'
            }
        });

        if (!admin) {
            await logApiCall(req, res, 404, `Viewed admin user - admin not found (ID: ${id})`, "user", parseInt(id));
            return res.status(404).json({ message: "Admin not found" });
        }

        await logApiCall(req, res, 200, `Viewed admin user: ${admin.fullName} (ID: ${id})`, "user", parseInt(id));
        res.json({ admin });
    } catch (error) {
        console.error("Error fetching admin by ID:", error);
        await logApiCall(req, res, 500, "Error occurred while fetching admin user", "user", parseInt(req.params.id) || 0);
        res.status(500).json({ message: "Server error", error: error.message });
    }
};

//toggle status active/inactive for admin and service-member 
exports.toggleAdminStatus = async (req, res) => {

    try {
        const { id } = req.params;

        //find admin user
        const user = await User.findByPk(id);

        if (!user) {
            await logApiCall(req, res, 404, `Toggled admin status - user not found (ID: ${id})`, "user", parseInt(id));
            return res.status(404).json({ message: "user not found" });
        }

        const allowedRoles = [3, 4];
        if (!allowedRoles.includes(user.role)) {
            return res.status(403).json({
                message: "You are not allowed to change this user status"
            });
        }
        const newStatus = user.status === 1 ? 0 : 1;

        await user.update({ status: newStatus });
        await logApiCall(req, res, 200, `user status to ${newStatus === 1 ? 'active' : 'inactive'} (ID: ${id})`, "user", parseInt(id));
        res.status(200).json({
            message: `User has been ${newStatus === 1 ? 'Activated' : 'Deactivated'} successfully.`,
            status: newStatus
        });
    } catch (error) {
        console.error("Error toggling admin:", error);
        await logApiCall(req, res, 500, "Error occurred while toggling user status", "user", parseInt(req.params.id) || 0);
        res.status(500).json({ message: "Error toggling admin", error: error.message });
    }
}
