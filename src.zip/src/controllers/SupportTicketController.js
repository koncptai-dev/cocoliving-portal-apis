const sequelize = require('../config/database');
const SupportTicket = require('../models/supportTicket');
const Rooms = require('../models/rooms');
const User = require('../models/user');
const Booking = require('../models/bookRoom');
const Property = require('../models/property');
const Inventory = require('../models/inventory');
const { Op } = require('sequelize');
const { logTicketEvent } = require("../utils/ticketLog");
const { generateSupportTicketCode } = require('../helpers/SupportTicketCode');
const { logApiCall } = require("../helpers/auditLog");
const { createFromTicket } = require("./serviceHistoryController");
const { notifyRequestUpdate } = require("../utils/notificationService");
const { createTicket: createAlisteTicket } = require('../utils/aliste/alisteApi');

//create tickets
exports.createTicket = async (req, res) => {
    try {
        const userId = req.user.id;
        const CATEGORY_MAP = {
            "Maintenance": [
                "Plumbing",
                "Electrical",
                "Appliance Issue",
                "Roommate Issue",
                "Other",
            ],
            "Payments & Refunds": [
                "Payment Not Reflecting Correctly",
                "Refund Not Received",
                "Request Refund",
                "Remaining Payment Issue",
                "Other",
            ],
            "Food Issue": [
                "Food Quality is not good",
                "Food Taste not good",
                "Other",
            ],
            "Other": [
                "Suggestion",
                "Complaint",
                "Feedback",
                "Other",
            ],
            "Electricity Recharge": [
                "Deductions",
                "Recharge",
                "Balance",
                "Room",
                "Other",
            ],
        };

        const ALISTE_SUBCATEGORY_MAP = {
            "Deductions": [
                "Over consumption",
                "Can't see deduction",
            ],

            "Recharge": [
                "Recharge not reflected",
                "Unable to recharge",
            ],

            "Balance": [
                "Wrong balance being shown",
            ],

            "Room": [
                "Wrong room number",
                "Room mate not added",
            ],

            "Other": [
                "Other",
            ],
        };

        const ALISTE_CATEGORY_MAPPING = {
            "Deductions": 1,
            "Recharge": 2,
            "Balance": 3,
            "Room": 4,
            "Other": 5,
        };

        const ALISTE_SUBCATEGORY_MAPPING = {
            "Over consumption": 0,
            "Can't see deduction": 1,

            "Recharge not reflected": 0,
            "Unable to recharge": 1,

            "Wrong balance being shown": 0,

            "Wrong room number": 0,
            "Room mate not added": 1,

            Other: 0,
        };
        const { roomNumber, date, issue, description, priority, inventoryId, category , subCategory , alisteSubcategory } = req.body;

        //validation
        if (!roomNumber || !date || !issue || !category || !subCategory) {
            await logApiCall(req, res, 400, "Failed to create support ticket - missing required fields", "supportTicket");
            return res.status(400).json({ message: "Please provide all required fields" });
        }
        if ( !CATEGORY_MAP[category] || !CATEGORY_MAP[category].includes(subCategory) ) {
            return res.status(400).json({
                message: "Invalid category/subCategory combination"
            });
        }
        if ( category === 'Electricity Recharge' ) {
            if (
                !alisteSubcategory ||
                !ALISTE_SUBCATEGORY_MAP[
                    subCategory
                ]?.includes(alisteSubcategory)
            ) {
                return res.status(400).json({
                    message:
                        'Invalid Aliste subcategory',
                });
            }
        }
        const today = new Date();

const booking = await Booking.findOne({
    where: {
        userId,

        onboardingStatus: 'COMPLETED',

        status: 'approved',

        checkInDate: {
            [Op.lte]: today,
        },

        checkOutDate: {
            [Op.gte]: today,
        },
    },

    include: [
        {
            model: Rooms,
            as: 'room',
            required: true,
        },

        {
            model: User,
            as: 'user',
            attributes: ['phone'],
        },
    ],

    order: [['createdAt', 'DESC']],
});


if (!booking) {
    return res.status(404).json({
        message: 'Active booking not found',
    });
}

const room = booking.room;

        // Optional inventory item linking
        let inventoryName = null;
        if (inventoryId) {
            const Inventory = require("../models/inventory");
            const inventory = await Inventory.findOne({ where: { id: inventoryId } });

            if (!inventory) {
                await logApiCall(req, res, 404, `Failed to create support ticket - inventory item not found (ID: ${inventoryId})`, "supportTicket");
                return res.status(404).json({ message: "Selected inventory item not found" });
            }

            // Optional validation: ensure inventory belongs to this room
            if (inventory.roomId !== room.id) {
                await logApiCall(req, res, 403, `Failed to create support ticket - inventory not part of room (ID: ${inventoryId})`, "supportTicket");
                return res.status(403).json({ message: "This inventory item is not part of your room" });
            }

            inventoryName = inventory.itemName;
        }

        //for images&video up to 10
        const imageUrls = req.files?.ticketImage?.map(file => `/uploads/ticketImages/${file.filename}`) || [];
        const videoUrls = req.files?.ticketVideo?.map(file => `/uploads/ticketVideos/${file.filename}`) || [];


        if (imageUrls.length > 10) {
            await logApiCall(req, res, 400, "Failed to create support ticket - too many images", "supportTicket");
            return res.status(400).json({ message: "You can upload a maximum of 10 images." });
        }
        if (videoUrls.length > 3) {
            await logApiCall(req, res, 400, "Failed to create support ticket - too many videos", "supportTicket");
            return res.status(400).json({ message: "You can upload a maximum of 3 videos." });
        }

        let externalTicketId = null;

        if (category === 'Electricity Recharge') {

            if (
                !room.alisteRoomId ||
                !booking.alisteUserId
            ) {
                return res.status(400).json({
                    message: 'Room is not linked with Aliste',
                });
            }

            const alisteCategory =
                ALISTE_CATEGORY_MAPPING[
                    subCategory
                ];

            const alisteSubcategoryNumber =
                ALISTE_SUBCATEGORY_MAPPING[
                    alisteSubcategory
                ];

            const payload = {
                category: alisteCategory,
                subcategory: alisteSubcategoryNumber,
                subject: issue,
                description: description || issue,
                userIdentifier: `+91${booking.user.phone.slice(-10)}`,
                roomId: room.alisteRoomId,
                attachmentsURLs: [],
            };

            let response;

            try {
                response =
                    await createAlisteTicket(
                        payload
                    );
            } catch (error) {
                console.error(
                    'Create Aliste Ticket Error:',
                    error.message
                );

                return res.status(500).json({
                    message: 'Failed to create ticket in Aliste',
                });
            }
            console.log(
                '[ALISTE CREATE TICKET RESPONSE]',
                JSON.stringify(response?.body, null, 2)
            );
            externalTicketId =
                response?.body?.data?.ticketId;
            console.log(
                '[ALISTE TICKET ID]',
                response?.body?.data?.ticketId
            );
            if (!externalTicketId) {
                return res.status(500).json({
                    message:
                        'Aliste ticket creation failed',
                });
            }
        }
        const supportCode = await generateSupportTicketCode(room.propertyId , room.roomNumber);
        const ticket = await SupportTicket.create({
            supportCode,
            roomId: room.id,
            roomNumber: room.roomNumber,
            propertyId: room.propertyId,
            date,
            issue,
            description,
            priority,
            userId,
            status: 'open',
            image: imageUrls,
            videos: videoUrls,
            inventoryId: inventoryId || null,
            inventoryName: inventoryName || null,
            category,
            subCategory,
            alisteSubcategory: alisteSubcategory || null,
            externalTicketId,
        })
        await logTicketEvent({
            ticketId: ticket.id,
            actionType: "TICKET_CREATED",
            newValue: { status: ticket.status },
            actorId: userId,
        });

        await logApiCall(req, res, 201, `Created support ticket: ${issue} (ID: ${ticket.id})`, "supportTicket", ticket.id);
        res.status(201).json({ message: "successfully created", ticket });
    } catch (error) {
        console.log(error);
        await logApiCall(req, res, 500, "Error occurred while creating support ticket", "supportTicket");
        res.status(500).json({ message: error.message });
    }
}

//users view own tickets 
exports.getUserTickets = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;

        const userId = req.user.id;

        const { rows: tickets, count } = await SupportTicket.findAndCountAll({
            where: {
                userId: userId
            }, 
            limit,
            offset,
            order: [['createdAt', 'DESC']]
        });
        const totalPages=Math.ceil(count / limit);

        await logApiCall(req, res, 200, "Viewed user support tickets list", "supportTicket");
        res.status(200).json({ tickets, currentPage: page, totalPages, totalTickets: count });
    } catch (error) {
        console.log(error);
        await logApiCall(req, res, 500, "Error occurred while fetching user support tickets", "supportTicket");
        res.status(500).json({ message: error.message });
    }
}

//admin view tickets
exports.getAllTickets = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;

        const { rows: tickets, count } = await SupportTicket.findAndCountAll({
            include: [
                {
                    model: Rooms,
                    as: 'room',     
                    attributes: ['id', 'roomNumber', 'propertyId'],
                    include: [
                        {
                            model: Property,
                            as: 'property',
                            attributes: ['id', 'name']
                        }
                    ]
                },
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'fullName', 'email']
                }
            ],
            limit,
            offset, order: [['createdAt', 'DESC']]
        });
        const totalPages = Math.ceil(count / limit);

        await logApiCall(req, res, 200, "Viewed all support tickets list", "supportTicket");
        res.status(200).json({ tickets, totalPages });
    } catch (error) {
        console.log(error);
        await logApiCall(req, res, 500, "Error occurred while fetching all support tickets", "supportTicket");
        res.status(500).json({ message: error.message });
    }
}

//admin updates  ticket status
exports.updateTicketStatus = async (req, res) => {
    const ticketId = req.params.id;
    try {
        const { status, assignedTo, resolutionNotes } = req.body;

        const userId = req.user.id;
        const userRole = req.user.role;

        const ticket = await SupportTicket.findByPk(ticketId);
        let statusChanged = false;

        if (!ticket) {
            await logApiCall(req, res, 404, `Updated support ticket status - ticket not found (ID: ${ticketId})`, "supportTicket", parseInt(ticketId));
            return res.status(404).json({ message: "Ticket not found" });
        }
        // Super Admin
        if (userRole === 1) {
            if ( typeof status !== "undefined" && status !== ticket.status ) {
            await logTicketEvent({
                ticketId: ticket.id,
                actionType: "STATUS_UPDATE",
                oldValue: { status: ticket.status },
                newValue: { status },
                actorId: userId,
            });

            ticket.status = status;
            statusChanged = true;
            }

            // ASSIGNMENT CHANGE
            if (typeof assignedTo !== "undefined" && assignedTo !== ticket.assignedTo) {

            let normalizedAssignedTo = null;

            if (assignedTo !== "" && assignedTo !== null) {
                const assignedUser = await User.findByPk(assignedTo);

                if (!assignedUser) {
                return res.status(404).json({ message: "User not found" });
                }

                if (![3, 4].includes(assignedUser.role)) {
                return res.status(400).json({
                    message: "Can only assign to admin or service team",
                });
                }
                normalizedAssignedTo = assignedUser.id;
            }

            await logTicketEvent({
                ticketId: ticket.id,
                actionType: "ASSIGNMENT",
                oldValue: { assignedTo: ticket.assignedTo },
                newValue: { assignedTo: normalizedAssignedTo },
                actorId: userId,
            });

            ticket.assignedTo = normalizedAssignedTo;
            }
        }
        // Normal Admin
        else if (userRole === 3) {
            if (ticket.assignedTo !== userId) {
                await logApiCall(req, res, 403, `Updated support ticket status - not assigned to ticket (ID: ${ticketId})`, "supportTicket", parseInt(ticketId));
                return res.status(403).json({ message: "You are not assigned to this ticket" });
            }
            // STATUS CHANGE
            if (typeof status !== "undefined" && status !== ticket.status) {
                await logTicketEvent({
                    ticketId: ticket.id,
                    actionType: "STATUS_UPDATE",
                    oldValue: { status: ticket.status },
                    newValue: { status },
                    actorId: userId,
                });

                ticket.status = status;
                statusChanged = true;
            }
        }

        // Resolution Notes validation
        const previousResolutionNotes = ticket.resolutionNotes;

        if ( typeof resolutionNotes !== "undefined" && resolutionNotes !== previousResolutionNotes ) {
            const effectiveStatus = typeof status !== "undefined" ? status : ticket.status;
            if (!["resolved"].includes(effectiveStatus)) {
                return res.status(400).json({
                message: "Resolution notes can only be added when status is resolved",
                });
            }

            if ( userRole !== 1 && !(userRole === 3 && ticket.assignedTo === userId )) {
                return res.status(403).json({ message: "Only assigned admins can add resolution notes", });
            }
            if (resolutionNotes !== null && resolutionNotes.trim() === "") {      
                return res.status(400).json({ message: "Resolution notes cannot be empty", });
            }
            ticket.resolutionNotes = resolutionNotes;

            await logTicketEvent({
                ticketId: ticket.id,
                actionType: previousResolutionNotes
                ? "RESOLUTION_NOTES_UPDATED"
                : "RESOLUTION_NOTES_ADDED",
                oldValue: previousResolutionNotes
                ? { resolutionNotes: previousResolutionNotes }
                : null,
                newValue: { resolutionNotes },
                actorId: userId,
            });
        }


        await ticket.save();
        if (statusChanged){
            await notifyRequestUpdate(ticket);
        }
        if (ticket.status && ["in-progress", "resolved"].includes(ticket.status.toLowerCase())) {
            const { createFromTicket } = require("../controllers/serviceHistoryController");
            await createFromTicket(ticket);
        }
        await logApiCall(req, res, 200, `Updated support ticket status to ${ticket.status} (ID: ${ticketId})`, "supportTicket", parseInt(ticketId));
        res.status(200).json({ message: "Ticket updated successfully", ticket });
    } catch (error) {
        console.log(error);
        await logApiCall(req, res, 500, "Error occurred while updating support ticket status", "supportTicket", parseInt(req.params.id) || 0);
        res.status(500).json({ message: error.message });
    }
}

// GET /api/rooms?status=active
exports.getRooms = async (req, res) => {
    try {
        const today = new Date();
        const userId = req.user.id;
        // Find bookings that are approved and currently active
        const activeBookings = await Booking.findAll({
            where: {
                status: 'approved',
                userId: userId,
                checkInDate: { [Op.lte]: today },
                checkOutDate: { [Op.gte]: today },
                roomId: { [Op.ne]: null }
            },
            include: [
                {
                    model: Rooms,
                    as: 'room',
                    attributes: ['id','roomNumber','propertyId'], // only need roomNumber
                    include: [
                        {
                            model: Property,
                            as: 'property',
                            attributes: ['name'], // include property name
                        }
                    ]
                },
            ],
        });

        // Extract unique room numbers
        const rooms = activeBookings
            .map((b) => b.room)
            .filter(Boolean)
            .map((r) => ({
                id: r.id,
                roomNumber: r.roomNumber,
                propertyId: r.propertyId,
                propertyName: r.property?.name || '',
            }));
        await logApiCall(req, res, 200, "Viewed active rooms for user", "supportTicket");
        res.status(200).json({ rooms });
  } catch (error) {
    console.error('Error fetching rooms:', error);
    await logApiCall(req, res, 500, "Error occurred while fetching active rooms", "supportTicket");
    res.status(500).json({ message: error.message });
  }
};
exports.getTicketDetails = async (req, res) => {
  try {
    const ticketId = req.params.id;
    const loggedInUser = req.user;

    const ticket = await SupportTicket.findOne({
      where: { id: ticketId },
      include: [
        {
          model: User,
          as: "user",
          attributes: ["id", "fullName", "email", "phone"],
        },
        {
          model: Rooms,
          as: "room",
          attributes: ["id", "roomNumber", "propertyId"],
          include: [
            {
              model: Property,
              as: "property",
              attributes: ["id", "name", "address"],
            },
          ],
        },
      ],
    });

    if (!ticket) {
      await logApiCall(req, res, 404, `Viewed support ticket details - ticket not found (ID: ${ticketId})`, "supportTicket", parseInt(ticketId));
      return res.status(404).json({ message: "Ticket not found" });
    }

    if (loggedInUser.role === 2) {
      if (ticket.userId !== loggedInUser.id) {
        await logApiCall(req, res, 403, `Viewed support ticket details - not authorized (ID: ${ticketId})`, "supportTicket", parseInt(ticketId));
        return res.status(403).json({ message: "You are not allowed to view this ticket" });
      }
    }
    let assignedAdmin = null;
    if (ticket.assignedTo) {
      assignedAdmin = await User.findOne({
        where: { id: ticket.assignedTo },
        attributes: ["id", "fullName", "email", "role"],
      });
    }

    let inventory = null;
    if (ticket.inventoryId) {
      inventory = await Inventory.findOne({
        where: { id: ticket.inventoryId },
        attributes: ["id", "inventoryCode", "itemName", "category", "status"],
      });
    }

    await logApiCall(req, res, 200, `Viewed support ticket details (ID: ${ticketId})`, "supportTicket", parseInt(ticketId));
    return res.status(200).json({
      success: true,
      message: "Ticket details fetched",
      ticket,
      assignedAdmin,
      inventory,
    });

  } catch (error) {
    console.log("getTicketDetails error:", error);
    await logApiCall(req, res, 500, "Error occurred while fetching support ticket details", "supportTicket", parseInt(req.params.id) || 0);
    return res.status(500).json({ message: error.message });
  }
};

exports.getAssignedTicketsForService = async (req, res) => {
  try {
    const userId = req.user.id;

    const tickets = await SupportTicket.findAll({
      where: {
        assignedTo: userId
      },
      include: [
        {
          model: Rooms,
          as: "room",
          attributes: ["roomNumber"],
          include: [{
            model: Property,
            as: "property",
            attributes: ["name"]
          }]
        },
        {
          model: User,
          as: "user",
          attributes: ["fullName"]
        }
      ],
      order: [["createdAt", "DESC"]]
    });

    return res.json({ tickets });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to fetch assigned tickets" });
  }
};

exports.updateTicketStatusByService = async (req, res) => {
  try {
    const ticketId = req.params.id;
    const { status, resolutionNotes } = req.body; 
    const userId = req.user.id;

    const ticket = await SupportTicket.findByPk(ticketId);

    if (!ticket) {
      return res.status(404).json({ message: "Ticket not found" });
    }

    if (ticket.assignedTo !== userId) {
      return res.status(403).json({ message: "Not your ticket" });
    }
    const allowedStatuses = ["open", "in-progress", "resolved"];

    if (!allowedStatuses.includes(status.toLowerCase())) {
    return res.status(400).json({ message: "Invalid status" });
    }

    if (status.toLowerCase() === "closed") {
      return res.status(403).json({
        message: "Service team cannot close tickets"
      });
    }

    await logTicketEvent({
      ticketId: ticket.id,
      actionType: "STATUS_UPDATE",
      oldValue: { status: ticket.status },
      newValue: { status },
      actorId: userId,
    });
    let statusChanged = false;
    if(ticket.status !== status){
        statusChanged = true;
    }
    // Handle resolution images
    const resolutionImages =  req.files?.resolutionImages?.map(file => `/uploads/ticketResolution/${file.filename}`) || [];

    // Only allow notes/images when resolving
    if (status.toLowerCase() === "resolved") {

        if (!resolutionNotes || resolutionNotes.trim() === "") {
            return res.status(400).json({
            message: "Resolution notes are required when resolving ticket"
            });
        }

        ticket.resolutionNotes = resolutionNotes;

        if (resolutionImages.length > 0) {
            const existing = ticket.resolutionImages || [];
            ticket.resolutionImages = [...existing, ...resolutionImages];
        }
    }
    ticket.status = status;
    await ticket.save();
    if (statusChanged){
        await notifyRequestUpdate(ticket);
    }
    if (["in-progress", "resolved"].includes(status.toLowerCase())) {
    await createFromTicket(ticket);
    }

    return res.json({ message: "Status updated", ticket });

  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update status" });
  }
};