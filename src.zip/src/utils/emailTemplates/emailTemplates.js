const path = require('path');

const CURRENT_YEAR = new Date().getFullYear();

const BASE_URL = process.env.FRONTEND_BASE_URL;

// ---------- COMMON ATTACHMENTS ----------
const baseAttachments = [
  { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
  { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
  { filename: 'quality.png', path: path.join(__dirname, 'assets/quality-spaces.png'), cid: 'quality' },
  { filename: 'tech.png', path: path.join(__dirname, 'assets/smart-tech.png'), cid: 'tech' },
  { filename: 'community.png', path: path.join(__dirname, 'assets/handshaking.png'), cid: 'community' },
  { filename: 'phone.png', path: path.join(__dirname, 'assets/phone-icon.png'), cid: 'phone' },
  { filename: 'mail.png', path: path.join(__dirname, 'assets/mail-icon.png'), cid: 'mail' },
  { filename: 'instagram.png', path: path.join(__dirname, 'assets/instagram.png'), cid: 'instagram' },
  { filename: 'facebook.png', path: path.join(__dirname, 'assets/facebook.png'), cid: 'facebook' },
  { filename: 'linkedin.png', path: path.join(__dirname, 'assets/linkedin.png'), cid: 'linkedin' },
];

const FOOTER_ATTACHMENTS = [
  { filename: 'phone.png', path: path.join(__dirname, 'assets/phone-icon.png'), cid: 'phone' },
  { filename: 'mail.png', path: path.join(__dirname, 'assets/mail-icon.png'), cid: 'mail' },
  { filename: 'instagram.png', path: path.join(__dirname, 'assets/instagram.png'), cid: 'instagram' },
  { filename: 'facebook.png', path: path.join(__dirname, 'assets/facebook.png'), cid: 'facebook' },
  { filename: 'linkedin.png', path: path.join(__dirname, 'assets/linkedin.png'), cid: 'linkedin' }
];

const FOOTER = `
<tr>
<td align="center" style="background:#4a2f1b;color:#fff;
padding:28px 20px;font-size:12px;line-height:1.6;">

  <div>© ${CURRENT_YEAR} COCO LIVING</div>
  <div>904-905 Palak Prime, Ambli Rd, Opp. DoubleTree by Hilton, Ahmedabad, Gujarat 380058</div>

  <div>
    <img src="cid:phone" width="9"/> +91-8141676967
    &nbsp;
    <img src="cid:mail" width="10"/> info@cocoliving.in
  </div>

  <div style="margin-top:6px;">
    Mon - Sat: 10:00 AM - 7:00 PM
  </div>

  <div style="margin:10px 0;">
    <a href="${BASE_URL}/privacy-policy" style="color:#fff;">Privacy Policy</a>
    &nbsp;&nbsp;
    <a href="${BASE_URL}/terms-and-conditions" style="color:#fff;">Terms & Conditions</a>
  </div>

 <div>
    <a href="https://www.instagram.com/cocoliving.in/">
      <img src="cid:instagram" width="18"/>
    </a>
    <a href="https://www.facebook.com/people/COCO-Living/">
      <img src="cid:facebook" width="18"/>
    </a>
    <a href="https://in.linkedin.com/company/collabcolony">
      <img src="cid:linkedin" width="18"/>
    </a>
  </div>

</td>
</tr>
`;

// bg logo quality tech community

// ---------- WELCOME EMAIL ----------
function welcomeEmail() {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      { filename: 'quality.png', path: path.join(__dirname, 'assets/quality-spaces.png'), cid: 'quality' },
      { filename: 'tech.png', path: path.join(__dirname, 'assets/smart-tech.png'), cid: 'tech' },
      { filename: 'community.png', path: path.join(__dirname, 'assets/handshaking.png'), cid: 'community' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>

<body style="margin:0;background:#f3efe9;
font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center">
<tr><td align="center">

<table width="600" style="max-width:600px;">

<tr>
<td align="center"
style="background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px 28px 90px;">
  <img src="cid:logo" width="140" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
  <div style="background:#f3efe9;border-radius:80px 80px 0 0;
  padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">
    <h1 style="margin:0 0 16px;font-size:34px;line-height:1.25;font-weight:700;">
      Welcome to Coco Living!<br/>Home Awaits!
    </h1>

    <p style="max-width:420px;margin:0 auto 28px;font-size:14px;line-height:1.6;color:#000;">
      We’re thrilled to have you join our community.
      Discover premium, blissful spaces where comfort,
      smart living, and community come together.
    </p>

    <a href="${BASE_URL}"
    style="display:inline-block;padding:14px 32px;background:#D36517;
    color:#fff;text-decoration:none;border-radius:24px;font-weight:600;">
      Explore Your New Home
    </a>
  </div>
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:16px;">
  <div style="background:#4F3421;color:#fff;width:90%;
  padding:16px 8px;font-size:14px;border-radius:12px;
  font-weight:600;letter-spacing:5px;">
    Find · Book · Move-in
  </div>
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:24px;">
<table width="100%"><tr>
<td align="center" width="33%" style="padding:14px;border:1px solid #D36517;
border-radius:10px;height:140px;font-weight:500;">
<img src="cid:quality" width="40"/><br/>Quality Spaces
</td>
<td align="center" width="33%" style="padding:14px;border:1px solid #D36517;
border-radius:10px;height:140px;font-weight:500;">
<img src="cid:tech" width="40"/><br/>Smart Tech
</td>
<td align="center" width="33%" style="padding:14px;border:1px solid #D36517;
border-radius:10px;height:140px;font-weight:500;">
<img src="cid:community" width="40"/><br/>Vibrant Community
</td>
</tr></table>
</td>
</tr>

${FOOTER}

</table>
</td></tr>
</table>
</body>
</html>
`
  };  
};

// ---------- OTP EMAIL (REDESIGNED) ----------
function otpEmail({ otp }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>

<body style="margin:0;background:#f3efe9;
font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center">
<tr><td align="center">

<table width="420" style="max-width:420px;">

<tr>
<td align="center"
style="background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px;">
  <img src="cid:logo" width="120" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:32px 24px;">
  <h2 style="margin:0 0 12px;font-size:22px;font-weight:700;">
    Verify your email
  </h2>

  <p style="margin:0 0 20px;font-size:14px;line-height:1.6;">
    Use the OTP below to continue signing in to Coco Living.
  </p>

  <div style="
    font-size:28px;
    font-weight:700;
    letter-spacing:6px;
    background:#ffffff;
    padding:16px 0;
    border-radius:12px;
    width:100%;
  ">
    ${otp}
  </div>

  <p style="margin-top:18px;font-size:12px;color:#555;">
    This OTP is valid for 5 minutes only. Please do not share it.
  </p>
</td>
</tr>

${FOOTER}

</table>
</td></tr>
</table>
</body>
</html>
`,
  };
}



function refundInitiatedEmail({ userName, bookingId, propertyName, refundAmount, reason }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html :`
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>
<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center"><tr><td align="center">
<table width="600" style="max-width:600px;">
 
<tr>
<td align="center" style="background-color:#4F3421;background-image:url(cid:bg);background-repeat:repeat;background-size:400px 400px;padding:28px 28px 90px;">
<img src="cid:logo" width="140" />
</td>
</tr>
 
<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
<div style="background:#f3efe9;border-radius:80px 80px 0 0;padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">
<h1 style="margin:0 0 16px;font-size:34px;font-weight:700;color:#28a745;">
      Refund Initiated 💸
</h1>
<p style="max-width:420px;margin:0 auto 28px;font-size:15px;line-height:1.6;">
      Hi ${userName},<br/><br/>
      Your refund has been initiated for the cancelled booking.
      The amount will be credited back to your original payment method soon.
</p>
 
    <div style="background:#ffffff;padding:24px;border-radius:12px;margin:24px 0;text-align:left;font-size:15px;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
<strong>Booking ID:</strong> #${bookingId}<br/>
<strong>Property:</strong> ${propertyName}<br/>
<strong>Refund Amount:</strong> ₹${refundAmount.toLocaleString('en-IN')}<br/>
      ${reason ? `<strong>Reason:</strong> ${reason}<br/>` : ''}
<br/>
<em>The amount will be credited within 5-7 business days depending on your bank/payment method.</em>
</div>
 
    <p style="font-size:15px;margin:20px 0;">
      Thank you for choosing Coco Living. We hope to welcome you soon!
</p>
 
    <a href="${BASE_URL}" style="display:inline-block;padding:14px 32px;background:#D36517;color:#fff;text-decoration:none;border-radius:24px;font-weight:600;">
      Explore Rooms Again
</a>
</div>
</td>
</tr>
 
${FOOTER}
 
</table>
</td></tr></table>
</body>
</html>
    ` 
  };  
};

function refundCompletedEmail({ userName, bookingId, propertyName, refundAmount }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>
<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center"><tr><td align="center">
<table width="600" style="max-width:600px;">
 
<tr>
<td align="center" style="background-color:#4F3421;background-image:url(cid:bg);padding:28px 28px 90px;">
<img src="cid:logo" width="140" />
</td>
</tr>
 
<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
<div style="background:#f3efe9;border-radius:80px 80px 0 0;padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">
<h1 style="margin:0 0 16px;font-size:34px;font-weight:700;color:#28a745;">
      Refund Completed ✅
</h1>
<p style="max-width:420px;margin:0 auto 28px;font-size:15px;line-height:1.6;">
      Hi ${userName},<br/><br/>
      Great news! Your refund has been successfully processed and credited to your account.
</p>
 
    <div style="background:#ffffff;padding:24px;border-radius:12px;margin:24px 0;text-align:left;font-size:15px;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
<strong>Booking ID:</strong> #${bookingId}<br/>
<strong>Property:</strong> ${propertyName}<br/>
<strong>Refunded Amount:</strong> ₹${refundAmount.toLocaleString('en-IN')}<br/><br/>
      The amount should now reflect in your bank account or original payment method.
</div>
 
    <p style="font-size:15px;margin:20px 0;">
      We hope to see you again soon at Coco Living!
</p>
 
    <a href="${BASE_URL}" style="display:inline-block;padding:14px 32px;background:#D36517;color:#fff;text-decoration:none;border-radius:24px;font-weight:600;">
      Book Your Next Stay
</a>
</div>
</td>
</tr>
 
${FOOTER}
 
</table>
</td></tr></table>
</body>
</html>
    `
  };  
};

// ----------ADMIN CREDENTIALS ----------
function adminCredentialsEmail({ fullName, email, password }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>

<body style="margin:0;background:#f3efe9;
font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center">
<tr><td align="center">

<table width="420" style="max-width:420px;">

<tr>
<td align="center"
style="background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px;">
  <img src="cid:logo" width="120" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:32px 24px;">
  <h2 style="margin:0 0 12px;font-size:22px;font-weight:700;">
    Admin Account Created
  </h2>

  <p style="margin:0 0 20px;font-size:14px;line-height:1.6;">
    Hello <strong>${fullName}</strong>,<br/>
    Your admin account has been successfully created.
  </p>

  <div style="
    background:#ffffff;
    padding:16px;
    border-radius:12px;
    width:100%;
    font-size:14px;
    line-height:1.8;
    text-align:left;
  ">
    <strong>Login Credentials</strong><br/><br/>
    Email: <strong>${email}</strong><br/>
    Password: <strong>${password}</strong>
  </div>

  <a href="${BASE_URL}/admin-login"
     style="
      display:inline-block;
      margin-top:20px;
      padding:12px 20px;
      background:#4F3421;
      color:#ffffff;
      text-decoration:none;
      border-radius:8px;
      font-size:14px;
      font-weight:600;
     ">
     Login to Admin Panel
  </a>
</td>
</tr>

${FOOTER}

</table>
</td></tr>
</table>
</body>
</html>
`
  };  
};

// schedule visit
function scheduledVisitEmail({ name, visitDate }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>
<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center"><tr><td align="center">
<table width="600" style="max-width:600px;">

<tr>
<td align="center" style="background-color:#4F3421;background-image:url(cid:bg);background-repeat:repeat;background-size:400px 400px;padding:28px 28px 90px;">
<img src="cid:logo" width="140" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
<div style="background:#f3efe9;border-radius:80px 80px 0 0;padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">

<h1 style="margin:0 0 16px;font-size:32px;font-weight:700;">
Visit Request Approved 📩
</h1>

<p style="max-width:420px;margin:0 auto 28px;font-size:15px;line-height:1.6;">
Hi <strong>${name}</strong>,<br/><br/>
Thank you for scheduling a visit with Coco Living.
Your request to visit our property has been approved.
</p>

<div style="background:#ffffff;padding:20px;border-radius:12px;margin:24px 0;text-align:centre;font-size:15px;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
Please visit during working hours on 
<strong>${new Date(visitDate).toLocaleDateString('en-IN')}</strong>.
</div>

<p style="font-size:15px;margin:20px 0;">
We look forward to welcoming you.
</p>

</div>
</td>
</tr>

${FOOTER}

</table>
</td></tr></table>
</body>
</html>
`
  };
}

function securityDepositPaymentEmail({ userName, propertyName, bookingId }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>

<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center"><tr><td align="center">

<table width="600" style="max-width:600px;">

<tr>
<td align="center"
style="background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px 28px 90px;">
<img src="cid:logo" width="140" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
<div style="background:#f3efe9;border-radius:80px 80px 0 0;padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">

<h1 style="margin:0 0 16px;font-size:32px;font-weight:700;">
Security Deposit Payment Required
</h1>

<p style="font-size:15px;line-height:1.6;">
Hi <strong>${userName}</strong>,<br/><br/>

Your rental agreement for <strong>${propertyName}</strong> has been successfully signed.
</p>

<p style="font-size:15px;line-height:1.6;">
To complete your booking process, please pay the
<strong>security deposit (2 months rent)</strong>.
</p>

<div style="background:#ffffff;padding:20px;border-radius:12px;margin:24px 0;text-align:left;font-size:15px;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
<strong>Booking ID:</strong> ${bookingId}<br/>
Please visit your <strong>My Booking</strong> page to complete the payment.
</div>

<a href="${BASE_URL}/user/bookings"
style="display:inline-block;padding:14px 32px;background:#D36517;color:#fff;text-decoration:none;border-radius:24px;font-weight:600;">
Pay Security Deposit
</a>

</div>
</td>
</tr>

${FOOTER}

</table>
</td></tr></table>
</body>
</html>
`
  };
}

function invoiceEmail({
  userName,
  invoiceNo,
  amount,
  paymentDate
}) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>

<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center">
<tr><td align="center">

<table width="600" style="max-width:600px;">

<tr>
<td align="center"
style="background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px 28px 90px;">
<img src="cid:logo" width="140" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
<div style="background:#f3efe9;border-radius:80px 80px 0 0;padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">

<h1 style="margin:0 0 16px;font-size:32px;font-weight:700;">
Invoice Generated 🧾
</h1>

<p style="font-size:15px;line-height:1.6;">
Hi <strong>${userName}</strong>,<br/><br/>

Your payment has been successfully processed and an invoice has been generated for your transaction.
Please find the <strong>invoice attached</strong> with this email for your records.
</p>

<div style="background:#ffffff;padding:24px;border-radius:12px;margin:24px 0;text-align:left;font-size:15px;box-shadow:0 2px 8px rgba(0,0,0,0.1);">

<strong>Invoice Details</strong><br/><br/>

<strong>Invoice No:</strong> ${invoiceNo}<br/>
<strong>Amount Paid:</strong> ₹${amount.toLocaleString('en-IN')}<br/>
<strong>Payment Date:</strong> ${new Date(paymentDate).toLocaleDateString('en-IN')}

</div>

<p style="font-size:15px;margin:20px 0;">
If you have any questions regarding this invoice, feel free to contact our support team.
</p>

</div>
</td>
</tr>

${FOOTER}

</table>
</td></tr>
</table>
</body>
</html>
`
  };
}

function acknowledgementReceiptEmail({ userName }) {
  return {
    attachments: [
      {
        filename: 'logo.png',
        path: path.join(__dirname, 'assets/logo.png'),
        cid: 'logo'
      },
      {
        filename: 'bg-pattern.png',
        path: path.join(__dirname, 'assets/bg-pattern.png'),
        cid: 'bg'
      },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8" />
</head>

<body style="margin:0;background:#f3efe9;
font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">

<table width="100%" align="center">
<tr>
<td align="center">

<table width="600" style="max-width:600px;">

<tr>
<td align="center"
style="
background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px 28px 90px;
">
  <img src="cid:logo" width="140" />
</td>
</tr>

<tr>
<td align="center"
style="background:#f3efe9;padding:0 24px 40px;">

<div style="
background:#f3efe9;
border-radius:80px 80px 0 0;
padding:40px 24px 0;
max-width:520px;
margin:-60px auto 0;
">

<h1 style="
margin:0 0 16px;
font-size:32px;
font-weight:700;
">
Payment Received
</h1>

<p style="
max-width:420px;
margin:0 auto 28px;
font-size:15px;
line-height:1.6;
">
Hi <strong>${userName}</strong>,<br/><br/>

We have successfully received your payment.
</p>

<div style="
background:#ffffff;
padding:24px;
border-radius:12px;
margin:24px 0;
text-align:left;
font-size:15px;
line-height:1.6;
box-shadow:0 2px 8px rgba(0,0,0,0.1);
">

Your <strong>acknowledgement receipt is attached</strong>
to this email for your records.

</div>

<p style="
font-size:15px;
margin:20px 0;
line-height:1.6;
">
Thank you for your payment.
</p>

</div>

</td>
</tr>

${FOOTER}

</table>

</td>
</tr>
</table>

</body>
</html>
`
  };
}

function rentDueAdminEmail({ reportMonth, tableRows, hasOverdue }) {
  const showTable = Boolean(hasOverdue);
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>

<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center">
<tr><td align="center">

<table width="600" style="max-width:600px;">

<tr>
<td align="center"
style="background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px 28px 90px;">
<img src="cid:logo" width="140" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
<div style="background:#f3efe9;border-radius:80px 80px 0 0;padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">

<h1 style="margin:0 0 16px;font-size:32px;font-weight:700;">
Rent Due Report - ${reportMonth}
</h1>

<p style="font-size:15px;line-height:1.6;">
${showTable
  ? "The following users have unpaid installments as of the 8th of this month:"
  : "No overdue payments found as of the 8th of this month."}
</p>

${showTable ? `
<table style="width:100%;border-collapse:collapse;margin-top:16px;font-size:13px;">
  <thead>
    <tr style="background:#f8f9fa;text-align:left;">
      <th style="border:1px solid #ddd;padding:8px;">User Name</th>
      <th style="border:1px solid #ddd;padding:8px;">Email</th>
      <th style="border:1px solid #ddd;padding:8px;">Phone</th>
      <th style="border:1px solid #ddd;padding:8px;">Installments (Paid/Total)</th>
      <th style="border:1px solid #ddd;padding:8px;">Rent/Month</th>
    </tr>
  </thead>
  <tbody>
    ${tableRows}
  </tbody>
</table>
` : ""}

<p style="margin-top:16px;font-size:12px;color:#777;">
Generated automatically by Coco Living System.
</p>

</div>
</td>
</tr>

${FOOTER}

</table>
</td></tr>
</table>
</body>
</html>
`
  };
}

function couponShareEmail({ title, code, discountValue, discountType, propertyName, endDate }) {
  const discountDisplay = discountType === 'percentage' ? `${discountValue}%` : `₹${discountValue}`;
  const propertyDisplay = propertyName ? propertyName : "All Coco Living Properties";
  const validUntilDisplay = new Date(endDate).toLocaleDateString('en-IN');

  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>
<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">
<table width="100%" align="center"><tr><td align="center">
<table width="600" style="max-width:600px;">

<tr>
<td align="center" style="background-color:#4F3421;background-image:url(cid:bg);background-repeat:repeat;background-size:400px 400px;padding:28px 28px 90px;">
<img src="cid:logo" width="140" />
</td>
</tr>

<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
<div style="background:#f3efe9;border-radius:80px 80px 0 0;padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">

<h1 style="margin:0 0 16px;font-size:32px;font-weight:700;">
Exclusive Offer For You! 🎉
</h1>

<p style="max-width:420px;margin:0 auto 28px;font-size:15px;line-height:1.6;">
Hi there,<br/><br/>
We're excited to share a special promotion with you: <strong>${title}</strong>.
Redeem your coupon in our app to get <strong>${discountDisplay} Off</strong>!
</p>

<div style="background:#ffffff;padding:20px;border-radius:12px;margin:24px 0;text-align:left;font-size:15px;box-shadow:0 2px 8px rgba(0,0,0,0.1);">
<strong>Coupon Code:</strong> <span style="font-family: monospace; font-size: 18px; color: #4F3421; font-weight: bold;">${code}</span><br/><br/>
<strong>Eligible Property:</strong> ${propertyDisplay}<br/>
<strong>Valid Until:</strong> ${validUntilDisplay}
</div>

<p style="font-size:15px;margin:20px 0;">
Apply this code at checkout to enjoy your discount. Don't wait, book your stay now!
</p>

</div>
</td>
</tr>

${FOOTER}

</table>
</td></tr></table>
</body>
</html>
    `
  };
}

function onboardingOtpEmail({ otp, userName }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<body style="margin:0;background:#f3efe9;font-family:'Rethink Sans','Inter',Arial;">
<table width="100%" align="center"><tr><td align="center">

<table width="420">

<tr>
<td align="center" style="background:#4F3421;background-image:url(cid:bg);padding:28px;">
<img src="cid:logo" width="120"/>
</td>
</tr>

<tr>
<td align="center" style="padding:32px 24px;">

<h2>Complete Your Move-in</h2>

<p>
Hi ${userName},<br/><br/>
Use this OTP to complete your onboarding process.
</p>

<div style="font-size:28px;font-weight:700;letter-spacing:6px;background:#fff;padding:16px;border-radius:12px;">
${otp}
</div>

<p style="font-size:12px;margin-top:12px;">
Valid for 5 minutes.
</p>

</td>
</tr>

${FOOTER}

</table>
</td></tr></table>
</body>
</html>
`
  };
}

function guestQrEmail({ guestName, visitDate }) {
  return {
    attachments: [
      ...FOOTER_ATTACHMENTS
    ],
    html: `
    <table width="100%">
    <tr><td>
<p>Hello <b>${guestName}</b>,</p>

<p>Your visit is scheduled on <b>${visitDate}</b>.</p>

<p>Please present the QR code below at the entrance.</p>

<img src="cid:guest-qr"/>

<p><b>Rules:</b></p>
<ul>
<li>Valid only for the visit date</li>
<li>Single-use</li>
<li>Scan required</li>
</ul>
</td></tr>
${FOOTER}
</table>
`
  };
}

function contractSignedEmail({ userName, bookingId }) {
  return {
    attachments: [
      { filename: 'logo.png', path: path.join(__dirname, 'assets/logo.png'), cid: 'logo' },
      { filename: 'bg-pattern.png', path: path.join(__dirname, 'assets/bg-pattern.png'), cid: 'bg' },
      ...FOOTER_ATTACHMENTS
    ],
    html: `
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8" /></head>

<body style="margin:0;background:#f3efe9;
font-family:'Rethink Sans','Inter','Segoe UI',Arial,sans-serif;">

<table width="100%" align="center">
<tr><td align="center">

<table width="600" style="max-width:600px;">

<!-- HEADER -->
<tr>
<td align="center"
style="background-color:#4F3421;
background-image:url(cid:bg);
background-repeat:repeat;
background-size:400px 400px;
padding:28px 28px 90px;">
  <img src="cid:logo" width="140" />
</td>
</tr>

<!-- CONTENT -->
<tr>
<td align="center" style="background:#f3efe9;padding:0 24px 40px;">
  <div style="background:#f3efe9;border-radius:80px 80px 0 0;
  padding:40px 24px 0;max-width:520px;margin:-60px auto 0;">

    <h1 style="margin:0 0 16px;font-size:32px;font-weight:700;">
      Agreement Successfully Signed 🎉
    </h1>

    <p style="max-width:420px;margin:0 auto 20px;font-size:15px;line-height:1.6;">
      Hi <strong>${userName}</strong>,<br/><br/>
      Your rental agreement has been successfully signed by both you and CoCo Living.
    </p>

    <div style="background:#ffffff;padding:20px;border-radius:12px;
    margin:24px 0;text-align:left;font-size:15px;
    box-shadow:0 2px 8px rgba(0,0,0,0.1);">

      <strong>Booking ID:</strong> ${bookingId}<br/><br/>
      Please find your <strong>fully signed agreement attached</strong> with this email for your records.

    </div>

    <p style="font-size:15px;margin:20px 0;">
      Welcome to Coco Living. We're excited to have you onboard!
    </p>

    <a href="${BASE_URL}/user/bookings"
    style="display:inline-block;padding:14px 32px;background:#D36517;
    color:#fff;text-decoration:none;border-radius:24px;font-weight:600;">
      View Booking
    </a>

  </div>
</td>
</tr>

${FOOTER}

</table>
</td></tr>
</table>

</body>
</html>
`
  };
}

module.exports = {
  welcomeEmail,
  otpEmail,
  refundInitiatedEmail,
  refundCompletedEmail,
  adminCredentialsEmail,
  scheduledVisitEmail,
  securityDepositPaymentEmail,
  invoiceEmail,
  acknowledgementReceiptEmail,
  rentDueAdminEmail,
  couponShareEmail,
  onboardingOtpEmail,
  guestQrEmail,
  contractSignedEmail,
  FOOTER,
  FOOTER_ATTACHMENTS
};
